import 'package:flutter/cupertino.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;
import '../model/notification.dart';

class NotificationService {
  static final _notifications = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;

    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Karachi'));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);

    final granted = await _notifications.initialize(settings);
    debugPrint('🔔 Notifications initialized: $granted');
    _initialized = true;
  }

  // ── Instant notification for testing ─────────────────────────────────────
  static Future<void> showInstantNotification({
    required String title,
    required String body,
  }) async {
    debugPrint('🔔 showInstantNotification called');
    await init();
    debugPrint('🔔 init done, showing notification...');
    try {
      await _notifications.show(
        0,
        title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'test_channel',
            'Test',
            importance: Importance.max,
            priority: Priority.high,
          ),
        ),
      );
      debugPrint('🔔 notification shown successfully');
    } catch (e) {
      debugPrint('🔔 ERROR showing notification: $e');
    }
  }

  // ── Schedule reminder before event ────────────────────────────────────────
  static Future<void> scheduleEventReminder({
    required int id,
    required String title,
    required DateTime eventTime,
  }) async {
    await init();

    final reminderTime = eventTime.subtract(const Duration(minutes: 1));

    if (reminderTime.isBefore(DateTime.now())) {
      debugPrint('🔔 Reminder time is in the past, skipping');
      return;
    }

    debugPrint('🔔 Scheduling reminder for $title at $reminderTime');

    await _notifications.zonedSchedule(
      id,
      '⏰ Event Reminder',
      '$title starts in 1 hour!',
      tz.TZDateTime.from(reminderTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'event_reminders',
          'Event Reminders',
          channelDescription: 'Reminders for upcoming events',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
      UILocalNotificationDateInterpretation.absoluteTime,
    );

    debugPrint('🔔 Reminder scheduled successfully');
  }

  // ── Cancel reminder ───────────────────────────────────────────────────────
  static Future<void> cancelReminder(int id) async {
    await _notifications.cancel(id);
  }

  // ── Instance methods for NotificationsScreen ──────────────────────────────
  final List<NotificationModel> _localNotifications = [];

  Future<List<NotificationModel>> fetchNotifications() async {
    return _localNotifications;
  }

  Future<void> markAsRead(String id) async {
    final index = _localNotifications.indexWhere((n) => n.id == id);
    if (index != -1) {
      _localNotifications[index] = NotificationModel(
        id: _localNotifications[index].id,
        message: _localNotifications[index].message,
        eventId: _localNotifications[index].eventId,
        time: _localNotifications[index].time,
        isRead: true,
      );
    }
  }

  // ── Schedule and track ────────────────────────────────────────────────────
  static Future<void> scheduleAndTrack({
    required int id,
    required String title,
    required DateTime eventTime,
    required NotificationService instance,
  }) async {
    await scheduleEventReminder(id: id, title: title, eventTime: eventTime);
    instance._localNotifications.add(NotificationModel(
      id: id.toString(),
      message: '⏰ $title starts in 1 hour!',
      eventId: title,
      time: _formatTime(eventTime.subtract(const Duration(minutes: 5))),
      isRead: false,
    ));
  }

  static String _formatTime(DateTime dt) {
    final hour = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final period = dt.hour >= 12 ? 'PM' : 'AM';
    return '$hour:${dt.minute.toString().padLeft(2, '0')} $period';
  }
}